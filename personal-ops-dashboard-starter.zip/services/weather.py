import requests

GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

def geocode_city(city):
    r = requests.get(GEOCODE_URL, params={'name': city, 'count': 1})
    r.raise_for_status()
    data = r.json()
    if not data.get('results'):
        return None
    res = data['results'][0]
    return {
        'name': res.get('name'),
        'lat': res.get('latitude'),
        'lon': res.get('longitude'),
        'country': res.get('country')
    }

def get_forecast(lat, lon):
    params = {
        'latitude': lat,
        'longitude': lon,
        'hourly': 'temperature_2m',
        'daily': 'weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum',
        'current_weather': True,
        'timezone': 'auto'
    }
    r = requests.get(FORECAST_URL, params=params)
    r.raise_for_status()
    return r.json()
