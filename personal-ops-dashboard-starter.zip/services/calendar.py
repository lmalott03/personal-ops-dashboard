from datetime import datetime, timedelta
from icalendar import Calendar

def parse_ics(file_bytes):
    cal = Calendar.from_ical(file_bytes)
    events = []
    now = datetime.now()
    horizon = now + timedelta(days=14)
    for component in cal.walk():
        if component.name == "VEVENT":
            summary = str(component.get('summary', ''))
            dtstart = component.get('dtstart').dt
            dtend = component.get('dtend').dt if component.get('dtend') else None
            location = str(component.get('location', '')) if component.get('location') else ''
            # Normalize to datetime for all-day events (date -> datetime)
            if hasattr(dtstart, 'date') and not hasattr(dtstart, 'hour'):
                dtstart = datetime(dtstart.year, dtstart.month, dtstart.day, 0, 0)
            if dtend and hasattr(dtend, 'date') and not hasattr(dtend, 'hour'):
                dtend = datetime(dtend.year, dtend.month, dtend.day, 0, 0)
            # Only include events in next 14 days
            if dtstart and now <= dtstart <= horizon:
                events.append({
                    'title': summary,
                    'start': dtstart,
                    'end': dtend,
                    'location': location
                })
    events.sort(key=lambda e: e['start'])
    return events
